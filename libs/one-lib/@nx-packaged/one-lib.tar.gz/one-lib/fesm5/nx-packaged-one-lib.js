var OneLib = /** @class */ (function () {
    function OneLib() {
    }
    OneLib.prototype.foo = function () {
        return "bar";
    };
    return OneLib;
}());

/**
 * Generated bundle index. Do not edit.
 */

export { OneLib };
//# sourceMappingURL=nx-packaged-one-lib.js.map
