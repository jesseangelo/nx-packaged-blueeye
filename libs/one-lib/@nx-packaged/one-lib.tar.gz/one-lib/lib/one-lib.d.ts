export declare class OneLib {
    foo(): string;
}
