class OneLib {
    foo() {
        return "bar";
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { OneLib };
//# sourceMappingURL=nx-packaged-one-lib.js.map
